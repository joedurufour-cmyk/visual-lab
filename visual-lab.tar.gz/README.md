# Visual Lab — Midjourney V8.1 Experiment Station

## What This Is
A private, offline-first tool for systematically testing Midjourney prompt variations. One variable at a time, logged results, copy-paste ready.

## Install on Android

### Option 1: Direct (Fastest)
1. Copy all 3 files to a folder on your phone
2. Open `index.html` in Chrome
3. Tap ⋮ → "Add to Home screen"
4. Done. Works offline.

### Option 2: Simple Server (if direct doesn't work)
```
python3 -m http.server 8080
```
Then visit `http://your-pc-ip:8080` from phone.

## How to Use

### 1. Forge Tab
- Paste your working prompt
- Toggle "Brutal Physique Mode" (auto-injects musculature)
- Lock elements you don't want to change
- Tap "Start Variation Builder"

### 2. Variations Tab
- Select which variable to test (Actress, Clothing, Setting, Lighting)
- Adjust Chaos (default 15 = sweet spot) and Stylization
- Tap "Generate Grid"
- Each card shows: changed variable, full prompt, Copy button
- Log results: ✅ Wujuuuu or ❌ Baneado

### 3. Compare Tab
- Select 2-4 variations
- See prompts side-by-side with differences
- Pick winner

### 4. Lab Notes
- Full history of all experiments
- Filter by status (win/fail/untested)
- Re-copy any past prompt

## Design Decisions
- **AMOLED black**: Saves battery, easy on eyes at 2 AM
- **Plain text always**: No markdown, no code blocks, mobile copy-paste
- **Large touch targets**: Thumb-friendly
- **No internet needed**: Once loaded, works anywhere
- **Local storage only**: Your prompts never leave the device

## Data
Everything lives in your browser's localStorage. Clear browser data = lose history. Export coming if needed.

## Files
- `index.html` — The entire app (single file)
- `manifest.json` — PWA install config
- `sw.js` — Offline cache

---

Built for mobile. Built for speed. Built for your workflow.
